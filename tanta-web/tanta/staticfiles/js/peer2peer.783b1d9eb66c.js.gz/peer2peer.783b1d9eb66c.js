// Root module
var p2p = (function () {
	var initModule = function ($container) {
		p2p.shell.initModule($container);
	};
	return { initModule: initModule};
}());